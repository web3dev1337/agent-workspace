# Checklist (2026-01-20)

This checklist tracks completion for the roadmap in `PLANS/2026-01-20/IMPLEMENTATION_PLAN.md`.

## Global process (repeat per PR)

- [ ] Branch created from updated `main`
- [ ] Issue reproduced and documented (notes in `PLANS/2026-01-20/ROLLING_LOG.md`)
- [ ] Fix implemented with minimal scope
- [ ] Unit tests run: `npm run test:unit`
- [ ] E2E tests run on safe port: `npm run test:e2e:safe` (or justified skip)
- [ ] Manual sanity check (focused, <5 minutes)
- [ ] Docs updated (requirements/plan/log as needed)
- [ ] Commit created (clear message)
- [ ] Pushed to `origin`
- [ ] PR opened (record PR URL in rolling log)
- [ ] PR merged

## Feature / Fix tracking

### Planning & docs
- [x] Requested changes captured (`REQUESTED_CHANGES.md`)
- [x] Implementation plan written (`IMPLEMENTATION_PLAN.md`)
- [x] Rolling log started (`ROLLING_LOG.md`)

### Reliability (highest priority)
- [x] Tab switching preserves terminal typing & sizing
- [x] Tab switching preserves sidebar selection state
- [x] Adding worktrees does not resurrect startup overlays
- [x] Adding worktrees does not “reset” existing terminals
- [x] Sidebar worktree list updates immediately (no “one behind”)
- [x] Terminal scroll does not jump to top
- [x] Commander terminal supports text paste (Ctrl/Cmd+V)
- [x] Single-click dashboard shortcut + return to tabs

### Status + UX cleanups
- [x] Status indicator colors are accurate and documented
- [x] Remove/hide non-functional “Dynamic layout”
- [x] Remove or fix empty “Quick actions” strip
- [x] Sidebar worktree list is compact
- [x] Conversation browser autocomplete dropdown is dismissible
- [x] Modal close buttons are usable (ports + conversations + worktree picker)

### Ports / services
- [x] Remove bottom-left “Services” list under worktrees
- [x] Ports/Services modal is large + card/grid layout
- [x] Ports/Services modal supports open + copy URL/port actions

### Worktree picker UX
- [x] Modal layout is large and usable without excessive scrolling
- [x] Grouping by category/framework + ungrouped sections
- [x] Sorting: most recently edited + most recently created
- [x] Recency filters (radio buttons)
- [x] Favorites (persisted)
- [x] Quick launch: oldest + most recent + choose any
- [x] Show branch + PR + merged status

### PR management
- [x] PR list view (mine by default)
- [x] Filter toggle for “others’ PRs”
- [x] “Ready for review” tagging (independent of PR creation)

### Diff viewer
- [x] Clicking 🔍 auto-starts diff viewer if needed
- [x] Diff viewer works without native SQLite
- [x] Diff viewer starts with orchestrator (`npm start`)
- [x] Diff viewer: compact header + scroll wheel navigation
- [x] Diff viewer: render Markdown + Mermaid (toggle raw/rendered)

### Naming / branding
- [x] UI copy updates: “Claude” → “Agent” where appropriate

### Agents
- [x] Detect agent type where feasible (Claude vs Codex vs other)
- [x] Simplify Codex start command / remove unnecessary hard-coded flags

### Config-driven buttons
- [x] Custom buttons are wired from config JSON
- [x] Cascaded config hierarchy works reliably
- [x] Dynamic port selection avoids collisions

### Skill + docs
- [x] Skill doc added for folder/worktree conventions
- [x] “Products” quick links: pull latest master + start + open/copy URL
