const { ProcessTelemetryService } = require('../../server/processTelemetryService');

describe('ProcessTelemetryService', () => {
  test('computes averages from task records', async () => {
    const now = Date.now();
    const iso = (ms) => new Date(ms).toISOString();

    const taskRecordService = {
      list: () => ([
        {
          id: 'a',
          createdAt: iso(now),
          updatedAt: iso(now),
          doneAt: iso(now),
          prMergedAt: iso(now),
          ticketMovedAt: iso(now),
          reviewStartedAt: iso(now - 10_000),
          reviewEndedAt: iso(now),
          promptSentAt: iso(now - 5_000),
          promptChars: 100,
          reviewedAt: iso(now),
          verifyMinutes: 5,
          reviewOutcome: 'approved'
        },
        {
          id: 'b',
          createdAt: iso(now),
          updatedAt: iso(now),
          doneAt: iso(now),
          ticketClosedAt: iso(now),
          reviewStartedAt: iso(now - 20_000),
          reviewEndedAt: iso(now),
          promptSentAt: iso(now - 4_000),
          promptChars: 300,
          reviewedAt: iso(now),
          verifyMinutes: 15,
          reviewOutcome: 'needs_fix'
        },
        {
          id: 'c',
          createdAt: iso(now),
          updatedAt: iso(now),
          // No review timer, no prompt
        }
      ])
    };

    const svc = new ProcessTelemetryService({ taskRecordService });
    const summary = await svc.getSummary({ lookbackHours: 24, force: true });

    expect(summary.recordsConsidered).toBe(3);
    expect(summary.reviewedCount).toBe(2);
    expect(summary.promptSentCount).toBe(2);
    expect(summary.createdCount).toBe(3);
    expect(summary.doneCount).toBe(2);
    expect(summary.prMergedCount).toBe(1);
    expect(summary.ticketMovedCount).toBe(1);
    expect(summary.ticketClosedCount).toBe(1);
    expect(summary.samples.reviewSeconds).toBe(2);
    expect(summary.samples.promptChars).toBe(2);
    expect(summary.samples.verifyMinutes).toBe(2);
    expect(summary.avgPromptChars).toBe(200);
    // Reviews: 10s and 20s -> avg 15s
    expect(Math.round(summary.avgReviewSeconds)).toBe(15);
    expect(summary.avgVerifyMinutes).toBe(10);
    expect(summary.outcomeCounts).toEqual(expect.objectContaining({ approved: 1, needs_fix: 1 }));
  });

  test('returns bucketed series + histograms', async () => {
    const realNow = Date.now;
    const now = 1_700_000_000_000;
    Date.now = () => now;
    const iso = (ms) => new Date(ms).toISOString();

    const taskRecordService = {
      list: () => ([
        {
          id: 'a',
          createdAt: iso(now - 40_000),
          updatedAt: iso(now),
          doneAt: iso(now - 20_000),
          prMergedAt: iso(now - 20_000),
          reviewStartedAt: iso(now - 10_000),
          reviewEndedAt: iso(now),
          promptSentAt: iso(now - 5_000),
          promptChars: 100
        },
        {
          id: 'b',
          createdAt: iso(now - 2 * 60 * 60 * 1000),
          updatedAt: iso(now - 2 * 60 * 60 * 1000),
          doneAt: iso(now - 2 * 60 * 60 * 1000),
          ticketMovedAt: iso(now - 2 * 60 * 60 * 1000),
          reviewStartedAt: iso(now - 2 * 60 * 60 * 1000 - 30_000),
          reviewEndedAt: iso(now - 2 * 60 * 60 * 1000),
          promptSentAt: iso(now - 2 * 60 * 60 * 1000 + 2_000),
          promptChars: 300
        }
      ])
    };

    try {
      const svc = new ProcessTelemetryService({ taskRecordService });
      const details = await svc.getDetails({ lookbackHours: 24, bucketMinutes: 60, force: true });

      expect(details).toEqual(expect.objectContaining({
        bucketMinutes: 60,
        reviewedCount: 2,
        promptSentCount: 2
      }));
      expect(Array.isArray(details.series)).toBe(true);
      expect(details.series.length).toBeGreaterThanOrEqual(1);
      expect(details.series[0]).toEqual(expect.objectContaining({
        t: expect.any(Number),
        reviewSamples: expect.any(Number),
        promptSamples: expect.any(Number),
        createdCount: expect.any(Number),
        doneCount: expect.any(Number),
        prMergedCount: expect.any(Number),
        ticketMovedCount: expect.any(Number),
        ticketClosedCount: expect.any(Number)
      }));

      const reviewHist = details?.histograms?.reviewSeconds;
      const promptHist = details?.histograms?.promptChars;
      expect(Array.isArray(reviewHist?.bins)).toBe(true);
      expect(Array.isArray(promptHist?.bins)).toBe(true);

      const sumBins = (bins) => bins.reduce((acc, b) => acc + Number(b?.count ?? 0), 0);
      expect(sumBins(reviewHist.bins)).toBe(2);
      expect(sumBins(promptHist.bins)).toBe(2);
      expect(reviewHist.maxCount).toBeGreaterThanOrEqual(1);
      expect(promptHist.maxCount).toBeGreaterThanOrEqual(1);
    } finally {
      Date.now = realNow;
    }
  });

  test('exports telemetry as csv', async () => {
    const realNow = Date.now;
    const now = 1_700_000_000_000;
    Date.now = () => now;
    const iso = (ms) => new Date(ms).toISOString();

    const taskRecordService = {
      list: () => ([
        {
          id: 'a',
          createdAt: iso(now),
          updatedAt: iso(now),
          reviewStartedAt: iso(now - 10_000),
          reviewEndedAt: iso(now),
          reviewOutcome: 'approved',
          verifyMinutes: 5,
          promptSentAt: iso(now - 5_000),
          promptChars: 100,
          tier: 2,
          ticketProvider: 'trello',
          ticketCardId: 'id,with,comma'
        },
        {
          id: 'b',
          createdAt: iso(now),
          updatedAt: iso(now),
          // telemetry exists via reviewedAt
          reviewStartedAt: iso(now - 20_000),
          reviewedAt: iso(now),
          reviewOutcome: 'needs_fix',
          verifyMinutes: 15,
          tier: 1
        },
        {
          id: 'c',
          createdAt: iso(now),
          updatedAt: iso(now),
          // createdAt counts as telemetry
          tier: 3
        }
      ])
    };

    try {
      const svc = new ProcessTelemetryService({ taskRecordService });
      const csv = await svc.exportCsv({ lookbackHours: 24 });
      const lines = csv.trim().split('\n');

      expect(lines[0]).toBe('id,createdAt,updatedAt,doneAt,reviewStartedAt,reviewEndedAt,reviewOutcome,verifyMinutes,promptSentAt,promptChars,prMergedAt,ticketMovedAt,ticketClosedAt,tier,ticketProvider,ticketCardId,ticketBoardId,prUrl');
      expect(lines.length).toBe(4);
      expect(lines[1]).toContain('a,');
      expect(lines[1]).toContain('"id,with,comma"');
      expect(lines[2]).toContain('b,');
      expect(lines[3]).toContain('c,');
    } finally {
      Date.now = realNow;
    }
  });

  test('exports telemetry as json', async () => {
    const realNow = Date.now;
    const now = 1_700_000_000_000;
    Date.now = () => now;
    const iso = (ms) => new Date(ms).toISOString();

    const taskRecordService = {
      list: () => ([
        {
          id: 'a',
          createdAt: iso(now),
          updatedAt: iso(now),
          reviewStartedAt: iso(now - 10_000),
          reviewEndedAt: iso(now),
          reviewOutcome: 'approved',
          verifyMinutes: 5,
          promptSentAt: iso(now - 5_000),
          promptChars: 100,
          tier: 2,
          ticketProvider: 'trello',
          ticketCardId: 'card-1'
        },
        {
          id: 'b',
          createdAt: iso(now),
          updatedAt: iso(now),
          // telemetry exists via reviewedAt
          reviewStartedAt: iso(now - 20_000),
          reviewedAt: iso(now),
          reviewOutcome: 'commented',
          verifyMinutes: 10,
          tier: 1
        },
        {
          id: 'c',
          createdAt: iso(now),
          updatedAt: iso(now),
          // createdAt counts as telemetry
          tier: 3
        }
      ])
    };

    try {
      const svc = new ProcessTelemetryService({ taskRecordService });
      const out = await svc.exportJson({ lookbackHours: 24 });
      expect(out).toEqual(expect.objectContaining({
        lookbackHours: 24,
        exportedAt: expect.any(String),
        records: expect.any(Array)
      }));
      expect(out.records.length).toBe(3);
      expect(out.records[0]).toEqual(expect.objectContaining({
        id: expect.any(String),
        updatedAt: expect.any(String),
        doneAt: expect.any(String),
        reviewStartedAt: expect.any(String),
        reviewEndedAt: expect.any(String),
        reviewOutcome: expect.any(String)
      }));
    } finally {
      Date.now = realNow;
    }
  });
});
