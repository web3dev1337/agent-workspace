# Creating Projects

## Vocabulary
- `category`: Top-level grouping from `config/project-types.json` (for example `games`, `tools`, `writing`).
- `framework`: Framework within a category (for example `hytopia`, `monogame`, `unity`).
- `template`: Lowest-level scaffold kit used to create starter files.
- `project`: The repository/folder you create.
- `worktree`: A working branch directory like `work1`, `work2`.
- `workspace`: Orchestrator config that owns sessions, terminals, and worktrees.

## Main Flow (UI)
1. Open Dashboard.
2. Click `New Project` card.
3. Complete wizard steps:
   - Describe project
   - Configure category -> framework -> template, plus GitHub mode/repo target/worktree count
   - Review and create
4. On success, click `Open Workspace`.

If you open the wizard while focused in an existing workspace/worktree, it now pre-suggests framework/template defaults from the current repository type when possible.

Quick entrypoints:
- `Alt+Shift+N` opens the New Project wizard.
- Terminal header `✨` button opens the same wizard.
- Settings -> Command Catalog -> `New Project Wizard` button opens the same wizard.
- `Ctrl/Cmd+K` opens Command Palette; run `open-new-project`.

GitHub behavior:
- Enable `Create GitHub Repository` to create/push a repo during project creation.
- Disable it for local-first projects (no remote required).
- Optional `Repository Target` accepts:
  - `owner/repo`
  - `repo-name` (uses optional `GitHub Org/User` as prefix)
  - Full remote URL (`https://...` or `git@...`)

## CLI Fallback
Use the scaffold CLI directly:

```bash
node scripts/create-project.js --help
```

Typical example:

```bash
node scripts/create-project.js \
  --category game \
  --framework hytopia \
  --template hytopia-game-starter \
  --name my-new-project \
  --init-git true \
  --worktree-count 1
```

Optional template hook controls:

```bash
node scripts/create-project.js \
  --name my-new-project \
  --run-post-create true \
  --allow-post-create-failure true
```

## Troubleshooting
- GitHub repo creation fails:
  - Ensure `gh auth status` is valid.
  - Re-run with GitHub creation disabled, then set remote manually.
- Taxonomy options missing:
  - Verify `config/project-types.json` exists and is valid JSON.
  - Check `/api/project-types` response in browser devtools.
- Template files missing:
  - Ensure either `templates/project-kits/<template-id>` or the fallback `templates/scaffolds/*` path exists.
- Wizard fails with workspace creation error:
  - Inspect server logs for `create-new-project` or `/api/projects/create-workspace`.
  - Confirm target base paths are writable.
